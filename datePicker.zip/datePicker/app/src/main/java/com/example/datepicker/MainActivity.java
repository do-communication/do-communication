package com.example.datepicker;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    DatePicker spinner, calendar;
    Button change, submit;
    boolean toggle = false;
    String day, month, year;
    LinearLayout linear;

    public void Show_Hide(View view){
        if(toggle) {
            spinner.setVisibility(View.GONE);
            calendar.setVisibility(View.VISIBLE);
            calendar.updateDate(spinner.getYear(), spinner.getMonth(), spinner.getDayOfMonth());
        }
        else{
            spinner.setVisibility(View.VISIBLE);
            spinner.updateDate(calendar.getYear(), calendar.getMonth(), calendar.getDayOfMonth());
            calendar.setVisibility(View.GONE);
        }
        toggle = !toggle;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        calendar = findViewById(R.id.calendar);
        submit = findViewById(R.id.submit);
        linear = findViewById(R.id.linear);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!toggle)
                {
                    day = String.valueOf(calendar.getDayOfMonth());
                    month = String.valueOf(calendar.getMonth() + 1);
                    year = String.valueOf(calendar.getYear());
                }

                snackBar();
            }
        });
    }
    public void snackBar(){
        Snackbar snackbar = Snackbar.make(linear, "DD/MM/YY" + ":   " + day + "/" + month + "/" + year, Snackbar.LENGTH_LONG)
                .setAction("Cancel", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                    }
                });
        snackbar.show();
    }
}